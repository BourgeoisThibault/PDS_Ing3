US ESIBANK 14 : Developement of notification service on android device

- Based on websocket communication 
- Supports fault-tolerance for certain notifications
- Supports Auto Switch Between Wi-Fi & Mobile Data Networks
- Pushes notifications (from server) to a native Android application
- Uses JSON format for communication
- ...