package com.esipe.esibankm.esibankm.models;

/**
 * Created by Usman ABID BUTT on 26/11/2017.
 */

public class MockUsers {

    private String nom;
    private String uid;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

}
