package Main;

import Services.DataProcessing;

/**
 * Created by jeremy on 11/05/2018.
 */
public class SentimentAnalysis {


    public static void main( String[] args )
    {
        DataProcessing SentimentAnalysis = new DataProcessing();
        SentimentAnalysis.run();

    }
}
